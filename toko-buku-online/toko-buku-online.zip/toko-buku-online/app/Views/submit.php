<?=$this->extend('layout');?>

<?=$this->section('main')?>
<div class="container p-5">
    <div class="container">
        <div class="alert alert-success">
            <strong>Success! </strong> Order Anda telah diproses. Silahkan konfirmasi pembayaran Anda ke  Whatsapp Admin
            <a href="https://wa.me/085758034247" class="btn btn-success">Hubungi</a>
        </div>
    </div>
<?=$this->endSection()?>